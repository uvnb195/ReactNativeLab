import React from "react";
import {Text,View} from "react-native";

const FirstApp = () => {
  return (
    <View
    style = {{
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
    }}>
      <Text> Đào Hữu Quân - PD09237</Text>
    </View>
  )
}

export default FirstApp;